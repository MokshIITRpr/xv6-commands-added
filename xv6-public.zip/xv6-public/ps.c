#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]) {
/*struct uproc *up;

    int sz=cps(up,64);
    for(int i=0;i<3;i++){
    	char *x;
    	sprintf(x,"name : %s\n"up[i].name);
    	write(2,x,sizeof(x));
    }*/
    cps();
    exit();
}

