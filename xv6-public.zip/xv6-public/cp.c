#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

char buf[512];

int
main(int argc, char *argv[])
{
  int fd1, fd2;
  if(argc < 3){
    printf(1,"Wrong No of Arguments\n");
    exit();
  }

  if((fd1 = open(argv[1], O_RDONLY)) < 0){
  	printf(1, "cp: cannot open %s\n", argv[1]);
  	exit();
  }
  
  if((fd2 = open(argv[2], O_CREATE | O_WRONLY)) < 0){
  	printf(1, "cp: cannot open %s\n", argv[2]);
  	close(fd1);
  	exit();
  }
  
   int n;
   
   while((n = read(fd1, buf, sizeof(buf))) > 0) {
    if (write(fd2, buf, n) != n) {
      printf(1, "cp: write error\n");
      close(fd1);
      close(fd2);
      exit();
    }
  }
  
  
  if(n < 0){
    printf(1, "cp: read error\n");
    close(fd1);
    close(fd2);
    exit();
  }
  close(fd1);
  close(fd2);
  exit();
}
